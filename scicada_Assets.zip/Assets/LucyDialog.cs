﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LucyDialog : MonoBehaviour
{
    int disposition = 2;
    bool introduced = false;
    string charName = "WINTERS, LUCY";
    string role = "NOVELIST";
    string sprite = "Sprites/portrait_lucy";


    public void summonUI()
    {
        UIControl.summonUI(this.charName, this.role, this.sprite);
    }


}
