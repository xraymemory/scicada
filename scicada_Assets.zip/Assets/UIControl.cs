﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using UnityEngine;
using UnityEngine.UI;


public class UIControl : MonoBehaviour
{

    public void Update()
    {

        var panel = GameObject.FindWithTag("DialogUI");

        if (Input.GetMouseButton(0) && panel.activeSelf &&
            !RectTransformUtility.RectangleContainsScreenPoint(
                panel.GetComponent<RectTransform>(),
                Input.mousePosition,
                Camera.main))
        {
            //panel.SetActive(false);
            clearUI();
        }
    }


    public static void summonUI(string charName, string roleStr, string spriteLoc, string[] topics = null)
    {
        GameObject dialog, portrait, name, role, prefabDialogChoice, dialogPlayerChoiceContainer;


        dialog = GameObject.FindWithTag("DialogUI");
        portrait = GameObject.Find("DialogPortrait");
        name = GameObject.Find("DialogName");
        role = GameObject.Find("DialogRole");
        prefabDialogChoice = GameObject.Find("PrefabDialogChoice");
        dialogPlayerChoiceContainer = GameObject.Find("DialogPlayerChoiceContainer");



        Image dialogImage = dialog.GetComponentsInChildren<Image>()[0];
        Image portraitImage = portrait.GetComponentsInChildren<Image>()[0];

        Text nameText = name.GetComponentsInChildren<Text>()[0];
        Text roleText = role.GetComponentsInChildren<Text>()[0];

        nameText.text = charName;
        roleText.text = roleStr;

        Color tempColor = dialogImage.color;
        tempColor.a = 0.80f;
        dialogImage.color = tempColor;

        Sprite portraitSprite = Resources.Load<Sprite>(spriteLoc);
        portraitImage.sprite = portraitSprite;
        tempColor.a = 0.85f;
        portraitImage.color = tempColor;

        if (topics.Length > 0)
        {
            RectTransform parentPanel;
            parentPanel = dialogPlayerChoiceContainer.GetComponent<RectTransform>();
            for (int i = 0; i < topics.Length; i++)
            {
                GameObject dialogChoice = (GameObject)Instantiate(prefabDialogChoice);

                dialogChoice.transform.SetParent(parentPanel, false);
                //dialogChoice.transform.localScale = new Vector3(1, 1, 1);



                Image dialogChoiceImage = dialogChoice.GetComponentsInChildren<Image>()[0];
                var choiceColor = dialogChoiceImage.color;
                choiceColor.a = 0.90f;
                dialogChoiceImage.color = choiceColor;

                Text dialogChoiceText = dialogChoice.GetComponentsInChildren<Text>()[0];

                dialogChoiceText.text = topics[i];

                Vector3 pos = dialogChoice.transform.position;
                pos.y -= (i * 0.5f);
                dialogChoice.transform.position = pos;

                dialogChoice.tag = "DialogChoice";
            }
        }

    }

    public static void clearUI()
    {
        GameObject dialog, portrait, name, role;

        dialog = GameObject.FindWithTag("DialogUI");
        portrait = GameObject.Find("DialogPortrait");
        name = GameObject.Find("DialogName");
        role = GameObject.Find("DialogRole");

        Image dialogImage = dialog.GetComponentsInChildren<Image>()[0];
        Image portraitImage = portrait.GetComponentsInChildren<Image>()[0];

        Text nameText = name.GetComponentsInChildren<Text>()[0];
        Text roleText = role.GetComponentsInChildren<Text>()[0];

        nameText.text = " ";
        roleText.text = " ";

        Color tempColor = dialogImage.color;
        tempColor.a = 0f;
        dialogImage.color = tempColor;
        portraitImage.color = tempColor;

        Destroy(GameObject.FindWithTag("DialogChoice"));
    }

}
