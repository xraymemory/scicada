﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Runtime.Versioning;
using System.Diagnostics;

public class HostDialog : MonoBehaviour
{

    int disposition = 3;
    bool introduced = false;
    string charName = "MOTIF, KLAUS";
    string role = "COLLECTOR";
    string sprite = "Sprites/host_new";
    string[] topics = new string[] { "ALIMONY", "ARCHITECTURE", "BASEMENT" };
 
    public void summonUI()
    {
        UIControl.summonUI(this.charName, this.role, this.sprite, this.topics);
    }


}
